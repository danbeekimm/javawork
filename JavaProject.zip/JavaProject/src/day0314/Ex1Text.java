package day0314;

public class Ex1Text {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello Java!");
		System.out.println("0�� ���� :"+args[0]);
		System.out.println("1�� ���� :"+args[1]);
	}

}
